.. mdinclude:: ../README.md

.. toctree::
    :hidden:

    scanner
    adapter
    sphero_edu
    toys
