=======
Scanner
=======
.. currentmodule:: spherov2.scanner

.. autofunction:: find_toys
.. autofunction:: find_toy
.. function:: find_R2D2(toy_name: str = None, **kwargs)

    Same as ``find_toy(toy_types=[R2D2], toy_name, **kwargs)``.

.. function:: find_R2Q5(toy_name: str = None, **kwargs)

    Same as ``find_toy(toy_types=[R2Q5], toy_name, **kwargs)``.