====
Toys
====

Sphero 2.0 / SPRK
=================
.. autoclass:: spherov2.toy.sphero.Sphero
    :members:
    :undoc-members:
    :show-inheritance:
    :member-order: bysource

Ollie
=====
.. autoclass:: spherov2.toy.ollie.Ollie
    :members:
    :undoc-members:
    :show-inheritance:
    :member-order: bysource

BB-8
====
.. autoclass:: spherov2.toy.bb8.BB8
    :members:
    :undoc-members:
    :show-inheritance:
    :member-order: bysource

BB-9E
=====
.. autoclass:: spherov2.toy.bb9e.BB9E
    :members:
    :undoc-members:
    :show-inheritance:
    :member-order: bysource

R2-D2
=====
.. autoclass:: spherov2.toy.r2d2.R2D2
    :members:
    :undoc-members:
    :show-inheritance:
    :member-order: bysource

R2-Q5
=====
.. autoclass:: spherov2.toy.r2q5.R2Q5
    :members:
    :undoc-members:
    :show-inheritance:
    :member-order: bysource

RVR
===
.. autoclass:: spherov2.toy.rvr.RVR
    :members:
    :undoc-members:
    :show-inheritance:
    :member-order: bysource